"""채팅 프로그램

Usage:
    chatserver <port>

Options:
    -h --help       도움말
    -V --version    버전 출력
"""
from docopt import docopt
from .server import ChatServer

def main():
    arguments = docopt(__doc__, version="채팅 프로그램 0.0.3")
    server = ChatServer(int(arguments['<port>']))
    server.serve()

if __name__ == '__main__':
    main()